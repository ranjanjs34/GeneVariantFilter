#!/usr/bin/python3
import os

Gene_list=input("Confirm the gene list file name:")
in_dir=input("\n\nPlease provide path where the annotated files are kept:")

print("\n\nReading the Genes!")
keywords = set()
with open(Gene_list) as list_file:
	for line in list_file:
		if line.strip():
			keywords.add(line.strip())


print("\n\nPreparing list of files to be Searched in the VCF files.")

for path, dirs, files in os.walk(in_dir):
	for f in files:
		filename=os.path.join(path, f)
		with open(filename) as master:
			with open("result.txt", 'a') as searchresults:
				searchresults.write(filename+"\n")
				for line in master:
					if set(line.split()[:-1]) & keywords:
						searchresults.write(line)
				searchresults.write("\n\n\n")		

print("\n\nDONE")
